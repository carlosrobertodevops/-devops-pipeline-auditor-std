Visão e fases do produto.
