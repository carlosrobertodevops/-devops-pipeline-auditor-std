Endpoints: /health, /repos, /findings, /scans/:repoId, /webhooks/github.
