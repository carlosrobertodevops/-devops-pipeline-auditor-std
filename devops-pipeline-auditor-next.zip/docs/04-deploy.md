Deploy local (compose) e Coolify.
