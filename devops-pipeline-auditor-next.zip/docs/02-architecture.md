Arquitetura: Next.js UI/API + Prisma + Postgres.
