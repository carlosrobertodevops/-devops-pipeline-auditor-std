# DevOps Pipeline Auditor — Monorepo (Next.js Full-Stack)
Veja docs/ para detalhes.
