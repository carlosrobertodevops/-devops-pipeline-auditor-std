export default function Page(){
  return(<div className="card"><h2>Bem-vindo!</h2><p>Conecte seu GitHub App e rode a primeira auditoria.</p>
  <a className="btn" href="/dashboard">Ir para o Dashboard</a></div>)
}